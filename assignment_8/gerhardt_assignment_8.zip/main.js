
var width = window.innerWidth;
var height = window.innerHeight;


var renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(width, height);
document.body.appendChild(renderer.domElement);
 
// create scene object
var scene = new THREE.Scene;


// create simple geometry and add to scene
// var cubeGeometry = new THREE.CubeGeometry(15,15, 15);
// //var cubeMaterial = new THREE.MeshLambertMaterial({ map: THREE.ImageUtils.loadTexture('crate.jpg')});
// var cubeMaterial = new THREE.MeshLambertMaterial({ color: 0xddaa66});
// var cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
 
 

// create perspective camera
var camera = new THREE.PerspectiveCamera(100, width / height, 0.1, 10000);
camera.position.y = 100;
camera.position.z = 10;
// add to scene and renderer
scene.add(camera); 
renderer.render(scene, camera);
// create the view matrix
// camera.lookAt(mesh.position);
var cameraLookAt = new THREE.Vector3(0 , 0 , -1);
var cameraLeft = new THREE.Vector3( -1 , 0 , 0);
var cameraUp = new THREE.Vector3().crossVectors( cameraLeft , cameraLookAt );

// add lighting and add to scene 
var pointLight = new THREE.PointLight(0xaabbcc);
pointLight.position.set(10, 120, 16);
scene.add(pointLight);
// scene.add(cube);
var array_of_mesh = [];
var g_width = 10, g_height = Math.random() * 30 , g_length = 10;
for ( var i = 0; i < 500; i ++ ) {
    g_height = (Math.random() * 100 )+10;
    var geometry = new THREE . BoxGeometry (g_width , g_height , g_length) ;
    var material = new THREE.MeshLambertMaterial ( { color : 0xffffff } ) ;
    var mesh = new THREE.Mesh( geometry , material ) ;
    mesh.position.x =  Math.random() * 800 - 400;
    mesh.position.y =  g_height/2;
    // mesh.position.y =  Math.random() * 800 - 400;
    mesh.position.z =  Math.random() * 800 - 400;
    mesh.needsUpdate = true ;
    array_of_mesh.push(mesh)
    scene.add( mesh ) ;

}





/*
var skyboxGeometry = new THREE.CubeGeometry(10000, 10000, 10000);
var skyboxMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000, side: THREE.DoubleSide });
var skybox = new THREE.Mesh(skyboxGeometry, skyboxMaterial);
scene.add(skybox);
 */
 
renderer.render(scene, camera);

var direction = 0;

var mouse = new THREE.Vector3();

var pitch, yaw = 0.001;
var yaw_diff, pitch_diff;

function onMouseMove( event ) {

	// calculate mouse position in normalized device coordinates
	// (-1 to +1) for both components
    previous_x = mouse.x;
    previous_y = mouse.y;

	mouse.x = (event.clientX / window.innerWidth ) * 2 - 1;
    mouse.y = - (event.clientY / window.innerHeight ) * 2 + 1;

    yaw = previous_x - mouse.x;
    pitch =  mouse.y;

    // console.log(yaw)
    console.log(pitch)


}


function doKeyDown(event) {
    var keyCode = event.which;
    if (keyCode == 87) {
        direction = 3;
    } else if (keyCode == 83) {
        direction = 4;
    } else if (keyCode == 65) {
        direction = 1;
    } else if (keyCode == 68) {
        direction = 2;
    } else if (keyCode == 32) {
        direction = 0;
    }
};


document.addEventListener("keydown", doKeyDown, false);

window.addEventListener( 'mousemove', onMouseMove, false );



function render() {
    // console.log(direction)s
    if(direction == 1){
        camera.position.add(cameraLeft);
        // camera.position.applyAxisAngle(cameraLookAt, 20);

    }
    else if(direction == 2){
        camera.position.sub(cameraLeft);
        // camera.position.applyAxisAngle(cameraLookAt, 20);
    }
    else if (direction == 3){
        // camera.position.applyAxisAngle(cameraLookAt, pitch);
        camera.position.add(cameraLookAt);
    }
    else if (direction == 4){
        // camera.position.applyAxisAngle(cameraLookAt, pitch);
        camera.position.sub(cameraLookAt);
    }
    // console.log(mouse.x, mouse.y)
    // camera.position.applyAxisAngle(cameraLeft, yaw);
    // camera.position = camera.position.applyAxisAngle(cameraUp, 20);

    camera.rotation.y += 1 * (yaw);
    if(pitch < 0){
        camera.rotation.x += -1 * (.005);
    }
    else{
        camera.rotation.x += 1 * (.005);
    }
    // camera.rotation.x += -1 * (pitch- .01);
    // console.log(yaw);
    // camera.rotation.x +=  .01;
    // camera.position.applyAxisAngle(cameraUp, .002);
    // camera.position.applyAxisAngle(cameraLeft, .002);
    // camera.position.applyAxisAngle(cameraLookAt, .002);


    renderer.render(scene, camera);
    requestAnimationFrame(render);


}
render();

